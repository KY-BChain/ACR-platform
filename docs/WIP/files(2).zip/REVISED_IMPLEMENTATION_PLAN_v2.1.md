# ACR PLATFORM - REVISED IMPLEMENTATION PLAN
## **Distributed DAPP Architecture: "DATA STAYS. RULES TRAVEL."**

**Version:** 2.1  
**Date:** April 3, 2026  
**Architecture:** Distributed Edge Computing + Federated Learning + Blockchain Audit  
**Core Principle:** DATA STAYS. RULES TRAVEL.

---

## 📋 **EXECUTIVE SUMMARY**

This revised implementation plan transforms ACR Platform from a centralized backend to a **distributed DAPP** (Decentralized Application) that respects data sovereignty and privacy.

**Key Changes from Original Plan:**
1. ❌ **OLD:** Centralized Spring Boot backend processing all patient data
2. ✅ **NEW:** Distributed microservices deployed at each hospital (edge computing)

3. ❌ **OLD:** Patient data sent to central server for processing
4. ✅ **NEW:** Reasoner deployed to hospital, processes data locally

5. ❌ **OLD:** Single database storing all patient records
6. ✅ **NEW:** Each hospital has own database (data never leaves premises)

7. ❌ **OLD:** Monolithic application
8. ✅ **NEW:** Modular microservices (pluggable domains)

**Benefits:**
- ✅ GDPR/HIPAA/Chinese data localization compliant by design
- ✅ Horizontally scalable to 100M+ users (distributed deployment)
- ✅ Energy efficient (no massive central data center)
- ✅ Privacy-preserving (patient data never transmitted)
- ✅ Federated learning (knowledge sharing without data sharing)
- ✅ Blockchain audit trail (immutable provenance)

---

## 🎯 **IMPLEMENTATION PHILOSOPHY**

### **"DATA STAYS. RULES TRAVEL" - What Does This Mean?**

**Traditional Centralized AI:**
```
Hospital A → Send patient data → Central AI Server → Process → Return result
Hospital B → Send patient data → Central AI Server → Process → Return result
...
(Patient data leaves hospital - GDPR/HIPAA violation)
(Requires massive data center - energy intensive)
(Single point of failure)
```

**ACR Platform Distributed DAPP:**
```
Hospital A:
  ├─ Patient data (STAYS at hospital)
  └─ ACR Reasoner Container (TRAVELS here from GitHub)
      ├─ Openllet + 58 SWRL rules
      ├─ Bayesian CDS module
      └─ Local PostgreSQL
      
Hospital B:
  ├─ Patient data (STAYS at hospital)
  └─ ACR Reasoner Container (TRAVELS here from GitHub)
      ├─ Same Openllet + same 58 SWRL rules
      ├─ Same Bayesian CDS module
      └─ Local PostgreSQL

... 10,000 hospitals, same pattern

Federated Learning Network:
  ├─ Hospital A → Gradients only (no patient data)
  ├─ Hospital B → Gradients only (no patient data)
  └─ Aggregator → Global model update → Distribute back

RSK Blockchain:
  └─ Immutable audit trail (inference logs, no patient data)
```

**Key Insight:** The "RULES" (Docker containers with ontology + reasoner) travel to hospitals. Patient data stays put.

---

## 📅 **WEEK 2 TIMELINE OVERVIEW**

| Day | Date | Focus | Deliverable |
|-----|------|-------|-------------|
| **6** | Fri Apr 3 (PM) | Microservice Architecture Refactor | Separate reasoner module |
| **7** | Sat Apr 4 | Docker Deployment Package | Hospital deployment kit ready |
| **8** | Tue Apr 7 | Multi-Hospital Testing | 2-node federated test passing |
| **9** | Wed Apr 8 | Blockchain + Agent Integration | RSK audit + Fetch.ai agents |
| **10** | Thu Apr 9 | Stakeholder Demo + Documentation | Production-ready DAPP |

**Total Development Time:** 4.5 days (Day 6 PM + Days 7-10)

---

## 📦 **DAY 6 (FRIDAY APRIL 3, PM) - MICROSERVICE REFACTOR**

**Time:** 2:00pm → 8:00pm (6 hours)  
**Status:** Phase I (Ontology validation) COMPLETE ✅  
**Objective:** Transform monolithic backend into modular microservices

---

### **TASK 1: Repository Restructure (30 min)**

**Create new microservices architecture:**

```bash
cd ~/DAPP/ACR-platform

# Backup current monolithic code
git checkout -b backup/monolithic-architecture
git add .
git commit -m "Backup: Monolithic architecture before refactor"

# Create new distributed architecture branch
git checkout -b feature/distributed-dapp-architecture

# Create microservices directory structure
mkdir -p microservices/{openllet-reasoner,bayesian-cds,mammoview-radiology,ehr-adapter,federated-learning,fetch-agents}
mkdir -p deployment/{docker,kubernetes,scripts}
mkdir -p governance/{ontologies,swrl-rules,commercial}
mkdir -p docs/{architecture,deployment,governance,api}

# Move validated ontology files
mv ACR-Ontology-v2.1 governance/ontologies/breast-cancer/

# Create deployment files directory
mkdir -p deployment/docker/{ontologies,init-db,bayesian-config}
```

**Deliverable:** New directory structure in place

---

### **TASK 2: Extract Openllet Reasoner Microservice (2 hours)**

**Create standalone reasoner service:**

**2a. Initialize Spring Boot microservice:**

```bash
cd microservices/openllet-reasoner

# Create Maven project structure
mkdir -p src/main/java/org/acr/reasoner/{api,service,ontology,model}
mkdir -p src/main/resources/{db/migration,config}
mkdir -p src/test/java/org/acr/reasoner
```

**2b. Copy core reasoning logic:**

Files to create (already generated):
- ✅ `OpenlletReasonerApplication.java` - Main application
- ✅ `OntologyLoader.java` - Domain-agnostic ontology loader
- ✅ `ReasonerService.java` - Request-scoped inference engine
- ✅ `ReasonerController.java` - REST API endpoints
- ✅ `Dockerfile` - Container image
- ✅ `application.properties` - Configuration
- ✅ `README.md` - Deployment guide

**2c. Create pom.xml with dependencies:**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    
    <groupId>org.acr.platform</groupId>
    <artifactId>openllet-reasoner</artifactId>
    <version>2.1.0</version>
    <packaging>jar</packaging>
    
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.0</version>
    </parent>
    
    <dependencies>
        <!-- Spring Boot -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        
        <!-- Openllet OWL Reasoner -->
        <dependency>
            <groupId>com.github.galigator.openllet</groupId>
            <artifactId>openllet-owlapi</artifactId>
            <version>2.6.5</version>
        </dependency>
        <dependency>
            <groupId>net.sourceforge.owlapi</groupId>
            <artifactId>owlapi-distribution</artifactId>
            <version>5.1.20</version>
        </dependency>
        
        <!-- PostgreSQL -->
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        
        <!-- Flyway for DB migrations -->
        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-core</artifactId>
        </dependency>
        
        <!-- Lombok (reduce boilerplate) -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

**2d. Test microservice locally:**

```bash
cd microservices/openllet-reasoner

# Build
mvn clean package

# Run locally
java -jar target/openllet-reasoner-2.1.0.jar \
  --acr.ontology.domain=breast-cancer \
  --acr.ontology.base-path=../../governance/ontologies

# Test inference
curl -X POST http://localhost:8080/api/v1/infer \
  -H "Content-Type: application/json" \
  -d '{"age":55,"er":90,"pr":80,"her2":"阴性","ki67":10}'

# Expected: {"molecularSubtype":"LuminalA",...}
```

**Deliverable:** Standalone reasoner microservice running locally ✅

---

### **TASK 3: Create Bayesian CDS Microservice (1 hour)**

**Create Python-based Bayesian enhancement service:**

```bash
cd microservices/bayesian-cds

# Create Python module structure
mkdir -p {bayesian,priors,tests}
touch bayesian/__init__.py
touch bayesian/enhancer.py
```

**Create `bayesian/enhancer.py`:**

```python
"""
ACR Platform - Bayesian CDS Module
Confidence scoring for molecular subtype classification
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np
from typing import Dict, Optional
import json

app = FastAPI(title="ACR Bayesian CDS", version="2.1.0")

class PatientData(BaseModel):
    age: int
    er: int
    pr: int
    her2: str
    ki67: int

class BayesianResult(BaseModel):
    confidence: float
    prior_probability: float
    likelihood: float
    posterior_probability: float

# Load priors from configuration
with open('/config/priors/age_subtype_priors.json') as f:
    AGE_SUBTYPE_PRIORS = json.load(f)

with open('/config/priors/biomarker_likelihoods.json') as f:
    BIOMARKER_LIKELIHOODS = json.load(f)

@app.post("/enhance")
async def enhance_confidence(
    patient: PatientData,
    molecular_subtype: str
) -> BayesianResult:
    """
    Calculate Bayesian confidence score for molecular subtype
    
    P(Subtype|Biomarkers) = P(Biomarkers|Subtype) * P(Subtype) / P(Biomarkers)
    """
    
    # Determine age group
    age_group = get_age_group(patient.age)
    
    # Get prior probability P(Subtype)
    prior = AGE_SUBTYPE_PRIORS[age_group][molecular_subtype]
    
    # Get likelihood P(Biomarkers|Subtype)
    likelihood = calculate_likelihood(patient, molecular_subtype)
    
    # Calculate posterior (normalized)
    posterior = prior * likelihood
    
    # Confidence score (0.0-1.0)
    confidence = min(1.0, posterior * 1.2)  # Scale factor
    
    return BayesianResult(
        confidence=round(confidence, 3),
        prior_probability=round(prior, 3),
        likelihood=round(likelihood, 3),
        posterior_probability=round(posterior, 3)
    )

def get_age_group(age: int) -> str:
    if age < 40:
        return "under_40"
    elif age < 50:
        return "40_49"
    elif age < 60:
        return "50_59"
    elif age < 70:
        return "60_69"
    else:
        return "70_plus"

def calculate_likelihood(patient: PatientData, subtype: str) -> float:
    # Simplified likelihood calculation
    # Production: Use full Bayesian network
    
    biomarker_evidence = BIOMARKER_LIKELIHOODS[subtype]
    
    # ER evidence
    er_match = (patient.er > 0) == biomarker_evidence["er_positive"]
    er_likelihood = 0.9 if er_match else 0.1
    
    # PR evidence
    pr_match = (patient.pr > 0) == biomarker_evidence["pr_positive"]
    pr_likelihood = 0.85 if pr_match else 0.15
    
    # HER2 evidence
    her2_match = ("阳性" in patient.her2) == biomarker_evidence["her2_positive"]
    her2_likelihood = 0.95 if her2_match else 0.05
    
    # Ki-67 evidence
    ki67_high = patient.ki67 >= 14
    ki67_match = ki67_high == biomarker_evidence["ki67_high"]
    ki67_likelihood = 0.8 if ki67_match else 0.2
    
    # Combined likelihood
    combined = er_likelihood * pr_likelihood * her2_likelihood * ki67_likelihood
    
    return combined

@app.get("/health")
async def health_check():
    return {"status": "UP", "service": "Bayesian CDS"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
```

**Create Dockerfile:**

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY bayesian/ ./bayesian/
COPY priors/ /config/priors/

EXPOSE 8081

CMD ["python", "-m", "uvicorn", "bayesian.enhancer:app", "--host", "0.0.0.0", "--port", "8081"]
```

**Create requirements.txt:**

```
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.0
numpy==1.26.2
```

**Deliverable:** Bayesian CDS microservice ready ✅

---

### **TASK 4: Create Hospital Deployment Stack (1 hour)**

**Create complete Docker Compose deployment:**

Already created: ✅ `hospital-stack.yml` (see above)

**Create supporting files:**

**1. `.env.example` (template for hospitals):**

```bash
# ACR Platform Hospital Deployment Configuration
# Copy this file to .env and customize for your hospital

# Database
DB_PASSWORD=change_this_to_secure_password

# Hospital Identification
HOSPITAL_ID=demo-hospital
HOSPITAL_NAME=Demo Hospital
HOSPITAL_REGION=EU

# Deployment Environment
DEPLOYMENT_ENV=production

# Compliance
HOSPITAL_WALLET_ADDRESS=0x1234...  # For blockchain audit

# Optional: Federated Learning
# FEDERATED_ENABLED=true
# FEDERATED_COORDINATOR_URL=https://federated.acragent.com
```

**2. `init-db/01_create_tables.sql`:**

```sql
-- ACR Platform - Initial Database Schema
-- Patient inference results (de-identified)

CREATE TABLE IF NOT EXISTS inference_results (
    id SERIAL PRIMARY KEY,
    patient_id_hash VARCHAR(64) NOT NULL,  -- SHA-256 hash, not actual ID
    molecular_subtype VARCHAR(50),
    confidence_score DECIMAL(5,3),
    execution_path VARCHAR(20),
    inference_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_patient_hash (patient_id_hash),
    INDEX idx_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    event_type VARCHAR(50),
    user_id VARCHAR(100),
    action VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB,
    
    INDEX idx_timestamp (timestamp),
    INDEX idx_event_type (event_type)
);

-- Compliance: Track consent
CREATE TABLE IF NOT EXISTS patient_consent (
    patient_id_hash VARCHAR(64) PRIMARY KEY,
    consent_given BOOLEAN DEFAULT FALSE,
    consent_date TIMESTAMP,
    consent_version VARCHAR(20),
    revoked BOOLEAN DEFAULT FALSE,
    revoked_date TIMESTAMP
);
```

**3. `deployment/scripts/deploy-hospital.sh`:**

```bash
#!/bin/bash
# ACR Platform - Hospital Deployment Script

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ACR Platform - Hospital Deployment                       ║"
echo "║   'DATA STAYS. RULES TRAVEL.'                               ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Check prerequisites
command -v docker >/dev/null 2>&1 || { echo "❌ Docker not installed"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo "❌ Docker Compose not installed"; exit 1; }

echo "✅ Prerequisites check passed"

# Check .env file
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Creating from template..."
    cp .env.example .env
    echo "⚠️  IMPORTANT: Edit .env and set DB_PASSWORD and HOSPITAL_ID"
    exit 1
fi

# Pull latest images
echo "📥 Pulling latest ACR Platform images..."
docker-compose -f hospital-stack.yml pull

# Start services
echo "🚀 Starting ACR Platform services..."
docker-compose -f hospital-stack.yml up -d

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 30

# Health check
echo "🏥 Checking service health..."
curl -f http://localhost:8080/api/v1/health || { echo "❌ Reasoner health check failed"; exit 1; }
curl -f http://localhost:8081/health || { echo "❌ Bayesian CDS health check failed"; exit 1; }

echo "✅ ACR Platform deployed successfully!"
echo ""
echo "Next steps:"
echo "  1. Access frontend: http://localhost"
echo "  2. Test inference: curl -X POST http://localhost:8080/api/v1/infer ..."
echo "  3. View logs: docker-compose -f hospital-stack.yml logs -f"
```

**Deliverable:** Complete hospital deployment package ready ✅

---

### **TASK 5: Test Local Deployment (30 min)**

**Test complete stack locally:**

```bash
cd ~/DAPP/ACR-platform/deployment/docker

# Deploy stack
./scripts/deploy-hospital.sh

# Verify all services running
docker-compose -f hospital-stack.yml ps

# Test inference through complete stack
curl -X POST http://localhost:8080/api/v1/infer \
  -H "Content-Type: application/json" \
  -d '{
    "age": 55,
    "er": 90,
    "pr": 80,
    "her2": "阴性",
    "ki67": 10
  }'

# Expected: Full inference result with Bayesian confidence

# Clean up
docker-compose -f hospital-stack.yml down
```

**Deliverable:** Local deployment tested and working ✅

---

### **Day 6 Completion Criteria:**

- ✅ Repository restructured for microservices
- ✅ Openllet Reasoner microservice extracted and working
- ✅ Bayesian CDS microservice created
- ✅ Hospital deployment stack (Docker Compose) ready
- ✅ Local deployment tested successfully
- ✅ All code committed to feature branch

**Time:** 6 hours (2:00pm → 8:00pm)

---

## 🚢 **DAY 7 (SATURDAY APRIL 4) - DOCKER & KUBERNETES DEPLOYMENT**

**Time:** 9:00am → 6:00pm (8 hours with breaks)  
**Objective:** Production-ready deployment packages

---

### **TASK 1: Build Production Docker Images (2 hours)**

**1a. Build and tag images:**

```bash
cd ~/DAPP/ACR-platform

# Build Openllet Reasoner
cd microservices/openllet-reasoner
docker build -t acr-platform/openllet-reasoner:2.1.0 .
docker tag acr-platform/openllet-reasoner:2.1.0 acr-platform/openllet-reasoner:latest

# Build Bayesian CDS
cd ../bayesian-cds
docker build -t acr-platform/bayesian-cds:2.1.0 .
docker tag acr-platform/bayesian-cds:2.1.0 acr-platform/bayesian-cds:latest

# Verify images
docker images | grep acr-platform
```

**1b. Push to container registry:**

```bash
# Tag for Docker Hub (or private registry)
docker tag acr-platform/openllet-reasoner:2.1.0 acrplatform/openllet-reasoner:2.1.0
docker tag acr-platform/bayesian-cds:2.1.0 acrplatform/bayesian-cds:2.1.0

# Push
docker push acrplatform/openllet-reasoner:2.1.0
docker push acrplatform/bayesian-cds:2.1.0
```

**Deliverable:** Production Docker images published ✅

---

### **TASK 2: Create Kubernetes Deployment (3 hours)**

**2a. Create Kubernetes manifests:**

See continuation in next message...

**Deliverable:** Kubernetes deployment package ready ✅

---

[Document continues with Day 7-10 detailed tasks, Federated Learning integration, Fetch.ai agents, RSK blockchain, multi-hospital testing, and stakeholder demo preparation]

---

## 📊 **SUCCESS METRICS**

**By End of Week 2:**
- ✅ Microservices architecture deployed
- ✅ Docker Compose working (small hospitals)
- ✅ Kubernetes working (large hospitals)
- ✅ 2-hospital federated test passing
- ✅ Blockchain audit trail operational
- ✅ Documentation complete
- ✅ Stakeholder demo successful

**Scale Validation:**
- ✅ Deployed at UCD Dublin (1 node)
- ✅ Deployed at ZZU Zhengzhou (1 node)
- ✅ Federated learning between 2 nodes working
- ✅ Gradients aggregated without patient data sharing

---

**END OF REVISED IMPLEMENTATION PLAN**
