# ACR Platform - Openllet Reasoner Microservice

**Version:** 2.1.0  
**Architecture:** Distributed DAPP - "DATA STAYS. RULES TRAVEL."  
**License:** Apache 2.0 (Open Source Core)

---

## 🎯 Purpose

The **Openllet Reasoner Microservice** is the core clinical reasoning engine of the ACR Platform. It provides guideline-based clinical decision support for medical AI applications.

**Key Features:**
- ✅ Domain-agnostic OWL/SWRL reasoning
- ✅ Edge computing deployment (on-premise)
- ✅ Privacy-preserving (patient data never leaves hospital)
- ✅ GDPR/HIPAA/Chinese data localization compliant
- ✅ Horizontally scalable (distributed deployment)
- ✅ Modular (pluggable ontologies for different medical domains)

---

## 🏗️ Architecture Principle

### **"DATA STAYS. RULES TRAVEL."**

```
┌─────────────────────────────────────────────┐
│  Hospital A (Dublin)                        │
│  ├─ Patient Data (stays here)              │
│  └─ ACR Reasoner Container (deployed here) │ ← RULES travel here
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│  Hospital B (Zhengzhou)                     │
│  ├─ Patient Data (stays here)              │
│  └─ ACR Reasoner Container (deployed here) │ ← RULES travel here
└─────────────────────────────────────────────┘

... 10,000 more hospitals, same pattern
```

**NOT centralized processing:**
- ❌ Patient data sent to central server
- ✅ Reasoner deployed to where data is
- ✅ Processing happens locally at hospital
- ✅ Only aggregated gradients shared (federated learning)

---

## 🚀 Quick Start

### **Prerequisites**

- Docker Engine 20.10+
- Docker Compose 2.0+
- 2 GB RAM minimum (4 GB recommended)
- 10 GB disk space

### **Deploy Complete Hospital Stack**

```bash
# Clone repository
git clone https://github.com/KY-BChain/ACR-platform.git
cd ACR-platform/deployment/docker

# Configure environment
cp .env.example .env
# Edit .env and set:
#   DB_PASSWORD=your_secure_password
#   HOSPITAL_ID=your_hospital_identifier
#   HOSPITAL_NAME="Your Hospital Name"

# Start all services
docker-compose -f hospital-stack.yml up -d

# Verify deployment
docker-compose -f hospital-stack.yml ps
docker-compose -f hospital-stack.yml logs -f openllet-reasoner

# Wait for services to be ready (~60 seconds)
```

### **Test Clinical Inference**

```bash
# Test inference endpoint
curl -X POST http://localhost:8080/api/v1/infer \
  -H "Content-Type: application/json" \
  -d '{
    "age": 55,
    "er": 90,
    "pr": 80,
    "her2": "阴性",
    "ki67": 10
  }'

# Expected response:
# {
#   "molecularSubtype": "LuminalA",
#   "treatments": [...],
#   "executionPath": "PRIMARY",
#   "inferenceTimeMs": 150,
#   "timestamp": "2026-04-03T14:30:00"
# }

# Health check
curl http://localhost:8080/api/v1/health

# Expected response:
# {
#   "status": "UP",
#   "reasoner": "READY"
# }
```

---

## 📦 Deployment Options

### **Option 1: Docker Compose (Recommended for Small-Medium Hospitals)**

**Best for:** 1-10 concurrent users, single server deployment

```bash
docker-compose -f hospital-stack.yml up -d
```

**Includes:**
- Openllet Reasoner
- Bayesian CDS
- PostgreSQL database
- Optional frontend UI

**Resource requirements:**
- CPU: 2 cores minimum (4 cores recommended)
- RAM: 2 GB minimum (4 GB recommended)
- Disk: 10 GB minimum (50 GB recommended)

---

### **Option 2: Kubernetes (Recommended for Large Hospitals)**

**Best for:** 100+ concurrent users, high availability, auto-scaling

```bash
# Deploy to Kubernetes cluster
kubectl apply -f deployment/kubernetes/hospital-deployment.yaml

# Or use Helm chart
helm install acr-reasoner deployment/kubernetes/helm-charts/acr-platform
```

**Features:**
- Auto-scaling (HPA)
- High availability (3+ replicas)
- Rolling updates (zero downtime)
- Persistent volumes for PostgreSQL

**Resource requirements:**
- Nodes: 3 minimum (for HA)
- CPU per node: 4 cores
- RAM per node: 8 GB
- Disk: 100 GB per node

---

### **Option 3: Standalone JAR (Development/Testing)**

```bash
# Build JAR
mvn clean package

# Run standalone
java -jar target/openllet-reasoner-2.1.0.jar \
  --acr.ontology.domain=breast-cancer \
  --acr.ontology.base-path=/path/to/ontologies

# Requires PostgreSQL running separately
```

---

## 🔧 Configuration

### **Ontology Configuration**

The reasoner is **domain-agnostic** and can load any medical ontology:

```
config/
└── ontologies/
    ├── breast-cancer/
    │   ├── ACR_Ontology_Full_v2_1.owl
    │   ├── acr_swrl_rules_v2_1.swrl
    │   └── acr_sqwrl_queries_v2_1.sqwrl
    ├── lung-cancer/
    │   └── Lung_Ontology.owl
    └── cardiology/
        └── Cardiology_Ontology.owl
```

**Switch domains:**

```bash
# Via environment variable
export ACR_ONTOLOGY_DOMAIN=lung-cancer

# Via docker-compose
environment:
  - ACR_ONTOLOGY_DOMAIN=lung-cancer

# Via application.properties
acr.ontology.domain=lung-cancer
```

---

### **Database Configuration**

**Development (SQLite):**
```properties
spring.datasource.url=jdbc:sqlite:acr_platform.db
spring.datasource.driver-class-name=org.sqlite.JDBC
```

**Production (PostgreSQL):**
```properties
spring.datasource.url=jdbc:postgresql://postgres:5432/acr_platform
spring.datasource.username=acr_admin
spring.datasource.password=${DB_PASSWORD}
```

---

### **Security Configuration**

**JWT Authentication (Production):**

```properties
security.jwt.enabled=true
security.jwt.secret=${JWT_SECRET}
security.jwt.expiration=3600000
```

**Hospital SSO Integration:**
```properties
security.sso.enabled=true
security.sso.provider=saml
security.sso.entity-id=${HOSPITAL_SSO_ENTITY_ID}
```

---

## 🔒 Compliance & Privacy

### **GDPR Compliance (EU)**

✅ Data residency enforced (patient data never leaves EU)  
✅ Right to erasure (patient data deletion)  
✅ Data minimization (only essential biomarkers processed)  
✅ Audit logging (all access tracked)  
✅ Encryption at rest and in transit

### **HIPAA Compliance (US)**

✅ Access controls (role-based permissions)  
✅ Audit trails (who accessed what, when)  
✅ Encryption (AES-256)  
✅ Secure transmission (TLS 1.3)  
✅ Business Associate Agreement (BAA) available

### **Chinese Data Localization**

✅ On-premise deployment (data stays in China)  
✅ No cross-border data transfer  
✅ Local audit logs  
✅ Compliant with PIPL (Personal Information Protection Law)

---

## 📊 Monitoring & Observability

### **Health Checks**

```bash
# Liveness probe (is service running?)
curl http://localhost:8080/actuator/health/liveness

# Readiness probe (is service ready to serve traffic?)
curl http://localhost:8080/actuator/health/readiness

# Full health details
curl http://localhost:8080/actuator/health
```

### **Metrics (Prometheus)**

```bash
# Prometheus metrics endpoint
curl http://localhost:8080/actuator/prometheus

# Key metrics:
# - jvm_memory_used_bytes
# - http_server_requests_seconds
# - acr_reasoner_inference_duration_seconds
# - acr_reasoner_inference_total
```

### **Logs**

```bash
# View logs (Docker)
docker-compose logs -f openllet-reasoner

# Logs location (container)
/config/logs/reasoner.log

# Log levels
export LOGGING_LEVEL_ORG_ACR=DEBUG  # DEBUG, INFO, WARN, ERROR
```

---

## 🔄 Updates & Maintenance

### **Update Ontology (Zero Downtime)**

```bash
# Copy new ontology files
cp ACR_Ontology_Full_v2_2.owl ./ontologies/breast-cancer/

# Restart reasoner (graceful shutdown)
docker-compose restart openllet-reasoner

# Verify new version loaded
curl http://localhost:8080/api/v1/info
```

### **Update Docker Image**

```bash
# Pull latest image
docker pull acr-platform/openllet-reasoner:latest

# Restart with new image
docker-compose up -d --no-deps openllet-reasoner
```

### **Database Backup**

```bash
# Backup PostgreSQL
docker-compose exec postgres pg_dump -U acr_admin acr_platform > backup_$(date +%Y%m%d).sql

# Restore from backup
docker-compose exec -T postgres psql -U acr_admin acr_platform < backup_20260403.sql
```

---

## 🌐 Multi-Site Deployment

### **Federated Learning Network**

```
Hospital A → Gradients → Federated Coordinator → Global Model
Hospital B → Gradients → Federated Coordinator → Global Model
Hospital C → Gradients → Federated Coordinator → Global Model
...
(NO patient data leaves hospitals)
```

**Enable federated learning:**

```properties
acr.federated.enabled=true
acr.federated.coordinator-url=https://federated.acragent.com
acr.federated.hospital-id=${HOSPITAL_ID}
```

### **Blockchain Audit Trail**

```properties
acr.blockchain.enabled=true
acr.blockchain.rsk-node-url=https://public-node.rsk.co
acr.blockchain.hospital-wallet=${HOSPITAL_WALLET_ADDRESS}
```

---

## 💰 Commercial Licensing

### **Pricing Tiers**

**Basic (Open Source):**
- ✅ Core reasoner (Apache 2.0)
- ✅ Breast cancer ontology
- ✅ Community support
- 💰 FREE

**Professional:**
- ✅ All Basic features
- ✅ Multi-domain ontologies (lung, cardiology, etc.)
- ✅ Priority support (8x5)
- ✅ SLA guarantees
- 💰 $50,000/hospital/year

**Enterprise:**
- ✅ All Professional features
- ✅ Custom ontology development
- ✅ Federated learning access
- ✅ Dedicated support (24x7)
- ✅ White-label option
- 💰 $200,000/hospital/year

---

## 🆘 Support

**Community Support:**
- GitHub Issues: https://github.com/KY-BChain/ACR-platform/issues
- Discussions: https://github.com/KY-BChain/ACR-platform/discussions

**Professional Support:**
- Email: support@acragent.com
- Portal: https://support.acragent.com

**Enterprise Support:**
- Dedicated Slack channel
- Direct engineering access
- Custom SLA

---

## 📚 Documentation

- **Architecture:** [DISTRIBUTED_ARCHITECTURE.md](../docs/architecture/)
- **Deployment:** [HOSPITAL_DEPLOYMENT_GUIDE.md](../docs/deployment/)
- **API Reference:** [API_REFERENCE.md](../docs/api/)
- **GDPR Compliance:** [GDPR_COMPLIANCE.md](../docs/governance/)
- **Ontology Development:** [ONTOLOGY_DEVELOPMENT_GUIDE.md](../docs/ontology/)

---

## 🤝 Contributing

ACR Platform is open source (Apache 2.0). Contributions welcome!

**Areas for contribution:**
- 🏥 Domain-specific ontologies (lung cancer, cardiology, etc.)
- 🔬 SWRL rule development (clinical guidelines)
- 🧪 Testing & validation
- 📖 Documentation improvements
- 🌍 Internationalization (translations)

See [CONTRIBUTING.md](../CONTRIBUTING.md) for guidelines.

---

## 📄 License

**Apache License 2.0**

Copyright © 2024-2026 ACR Platform Contributors

Licensed under the Apache License, Version 2.0. See [LICENSE](../LICENSE) for details.

---

## 🙏 Acknowledgments

**Academic Partners:**
- University College Dublin (Ireland/EU)
- Zhengzhou University (China)

**Technology Partners:**
- Openllet (OWL Reasoner)
- Fetch.ai (Multi-Agent Framework)
- RSK (Blockchain Infrastructure)

**Clinical Guidelines:**
- NCCN (National Comprehensive Cancer Network)
- CSCO (Chinese Society of Clinical Oncology)
- ESMO (European Society for Medical Oncology)
- ASCO (American Society of Clinical Oncology)

---

**Built with ❤️ for global healthcare. "DATA STAYS. RULES TRAVEL."**
